A Pen created at CodePen.io. You can find this one at http://codepen.io/michaelmcqueen/pen/GdroF.

 A responsive e-commerce checkout bar for a site I'm working on at the moment. Still needs some love but it's a start.